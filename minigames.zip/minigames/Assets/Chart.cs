﻿using System.Collections;
using UnityEngine;

public class Chart : MonoBehaviour
{
    public SpriteRenderer Renderer;
    public Sprite BaseSprite;
    private Texture2D _texture;

    public int[] Values;
    
    public void Awake()
    {
        Values = new int[69];
        Values[0] = 0;
        for (var i = 1; i < Values.Length; i++)
        {
            Values[i] = Values[i-1] + Random.Range(-1, 2);
            if (Values[i] > 9)
            {
                Values[i] = 9;
            }

            if (Values[i] < -9)
            {
                Values[i] = -9;
            }
        }

        var oldPos = transform.position;
        var newTexture2D = Instantiate(BaseSprite.texture);
        var oldSprite = Renderer.sprite;
        Renderer.sprite = Sprite.Create(newTexture2D, oldSprite.rect, oldSprite.pivot);
//        Renderer.transform.position = oldPos;
        
        
        StartCoroutine(RunChart());
    }

    private IEnumerator RunChart()
    {
        DrawChart();
        yield return null;
    }

    private void DrawChart()
    {
        var originX = 1;
        var originY = 10;

        for (var i = 0; i < Values.Length; i++)
        {
            if (Values[i] > 0)
            {
                Renderer.sprite.texture.SetPixel(originX + i, originY + Values[i], Color.green);
            }
            else
            {
                Renderer.sprite.texture.SetPixel(originX + i, originY + Values[i], Color.red);                
            }
        }
        Renderer.sprite.texture.Apply();
    }
}