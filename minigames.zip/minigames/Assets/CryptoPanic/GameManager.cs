﻿using JFCUtil.Game;
using UnityEngine;

public class GameManager : MonoBehaviour, IGameClass
{
	public int Cash;
	public int Crypto;
	public int Value;

	public GameManager()
	{
		Cash = 0;
		Crypto = 100;
		Value = 5;
	}
	
	public int GetScoreOutOfOneHundred()
	{
		return 100;
	}

	public void AffectScore(int affect)
	{
		return;
	}
}
